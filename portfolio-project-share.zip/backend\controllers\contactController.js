import Contact from '../models/Contact.js';
import { validationResult } from 'express-validator';
import mongoose from 'mongoose';

/**
 * Sends real-time WhatsApp alert to the developer.
 * Mobile number and API key stay completely safe on server-side (.env).
 */
async function sendWhatsAppAlert({ name, email, subject, message }) {
  const phone = process.env.WHATSAPP_PHONE;
  const apiKey = process.env.WHATSAPP_API_KEY;

  if (!phone) return;

  try {
    const text = encodeURIComponent(
      `🚀 *New Contact Form Submission*\n\n` +
      `👤 *From:* ${name}\n` +
      `📧 *Email:* ${email}\n` +
      `📌 *Subject:* ${subject || 'Portfolio Inquiry'}\n` +
      `💬 *Message:* ${message}\n\n` +
      `⏰ *Time:* ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}`
    );

    if (apiKey) {
      // CallMeBot WhatsApp API
      const url = `https://api.callmebot.com/whatsapp.php?phone=${phone}&text=${text}&apikey=${apiKey}`;
      await fetch(url);
    }
  } catch (err) {
    console.error('WhatsApp notification dispatch error:', err.message);
  }
}

export const submitContact = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email, subject, message } = req.body;

  try {
    if (mongoose.connection.readyState === 1) {
      const contact = new Contact({ name, email, subject, message });
      await contact.save();
    }

    // Dispatch WhatsApp notification (asynchronous, non-blocking)
    sendWhatsAppAlert({ name, email, subject, message });

    res.status(201).json({ message: 'Message received and notification dispatched successfully' });
  } catch (error) {
    next(error);
  }
};

export const getContacts = async (req, res, next) => {
  try {
    if (mongoose.connection.readyState === 1) {
      const contacts = await Contact.find().sort('-createdAt');
      res.json(contacts);
    } else {
      res.json([]);
    }
  } catch (error) {
    next(error);
  }
};
