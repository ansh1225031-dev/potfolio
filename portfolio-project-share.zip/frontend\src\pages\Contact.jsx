import { useState } from 'react';
import ScrollReveal from '../components/ScrollReveal';
import { personalInfo } from '../data/personal';
import api from '../services/api';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }
    if (!formData.message.trim()) newErrors.message = 'Message is required';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setLoading(true);
    setStatus(null);

    try {
      await api.sendMessage(formData);
      setStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setStatus(null), 5000);
    } catch (error) {
      console.error('Error sending message:', error);
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="contact-hero container">
        <ScrollReveal>
          <h2 className="heading-display">GET IN<br />TOUCH</h2>
          <p className="text-body--lg" style={{ marginTop: 'var(--space-md)', maxWidth: '500px' }}>
            Have a question, want to collaborate, or just want to say hello? I'd love to hear from you.
          </p>
        </ScrollReveal>
      </div>

      <div className="container">
        <div className="contact-layout">
          <div className="contact-info">
            <ScrollReveal>
              <div className="contact-info__item">
                <span className="contact-info__label">Email</span>
                <span className="contact-info__value">
                  <a href={`mailto:${personalInfo.email}`}>{personalInfo.email}</a>
                </span>
              </div>
              <div className="contact-info__item">
                <span className="contact-info__label">Location</span>
                <span className="contact-info__value">{personalInfo.location}</span>
              </div>
              <div className="contact-info__item">
                <span className="contact-info__label">Availability</span>
                <span className="contact-info__value">Open to opportunities and collaborations</span>
              </div>
            </ScrollReveal>
          </div>

          <ScrollReveal delay={0.2}>
            <form className="contact-form" onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label className="form-group__label" htmlFor="contact-name">Name</label>
                <input className="form-group__input" type="text" id="contact-name" name="name" value={formData.name} onChange={handleChange} placeholder="Your name" />
                {errors.name && <span className="form-group__error">{errors.name}</span>}
              </div>

              <div className="form-group">
                <label className="form-group__label" htmlFor="contact-email">Email</label>
                <input className="form-group__input" type="email" id="contact-email" name="email" value={formData.email} onChange={handleChange} placeholder="your@email.com" />
                {errors.email && <span className="form-group__error">{errors.email}</span>}
              </div>

              <div className="form-group">
                <label className="form-group__label" htmlFor="contact-subject">Subject</label>
                <input className="form-group__input" type="text" id="contact-subject" name="subject" value={formData.subject} onChange={handleChange} placeholder="What's this about?" />
              </div>

              <div className="form-group">
                <label className="form-group__label" htmlFor="contact-message">Message</label>
                <textarea className="form-group__textarea" id="contact-message" name="message" value={formData.message} onChange={handleChange} placeholder="Tell me about your idea..." rows="5" />
                {errors.message && <span className="form-group__error">{errors.message}</span>}
              </div>

              <button type="submit" className={`btn btn--primary ${loading ? 'btn--loading' : ''}`} style={{ width: '100%', justifyContent: 'center' }} disabled={loading}>
                {loading ? (<><div className="loading-spinner" /> Sending...</>) : 'SEND MESSAGE →'}
              </button>

              {status === 'success' && (
                <div className="form-status form-status--success">✓ Message sent successfully! I'll get back to you soon.</div>
              )}
              {status === 'error' && (
                <div className="form-status form-status--error">✕ Failed to send message. Please try again or email me directly.</div>
              )}
            </form>
          </ScrollReveal>
        </div>
      </div>
    </>
  );
}
