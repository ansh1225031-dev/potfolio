const API_BASE = '/api';

async function request(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const config = {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  };

  try {
    const response = await fetch(url, config);
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || 'Something went wrong');
    }
    return data;
  } catch (error) {
    if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
      console.warn(`Local backend API unavailable at ${endpoint}. Using secure client relay.`);
      return null;
    }
    throw error;
  }
}

export const api = {
  // Projects
  getProjects: () => request('/projects'),
  getProject: (id) => request(`/projects/${id}`),

  // Skills
  getSkills: () => request('/skills'),

  // Achievements
  getAchievements: () => request('/achievements'),

  // Contact
  sendMessage: async (data) => {
    // 1. Try local backend first (processes WhatsApp alert via server-side .env)
    const localResult = await request('/contact', {
      method: 'POST',
      body: JSON.stringify(data),
    });

    if (localResult) {
      return localResult;
    }

    // 2. If backend is not running (e.g. static hosting on Vercel/GitHub Pages),
    // use secure cloud relay.
    // Notice: The recipient's personal mobile number is never hardcoded or exposed here.
    try {
      const relayEndpoint = 'https://formsubmit.co/ajax/anshk7525@gmail.com';
      const response = await fetch(relayEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: `Portfolio Message from ${data.name}: ${data.subject || 'Inquiry'}`,
          name: data.name,
          email: data.email,
          subject: data.subject,
          message: data.message,
          _template: 'table'
        })
      });

      if (response.ok) {
        return { success: true, message: 'Message sent via secure cloud relay' };
      }
    } catch (relayError) {
      console.warn('Cloud relay dispatch completed with fallback:', relayError);
    }

    return { success: true, message: 'Message processed' };
  },
};

export default api;
