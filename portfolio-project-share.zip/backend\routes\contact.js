import express from 'express';
import { submitContact, getContacts } from '../controllers/contactController.js';
import { body } from 'express-validator';

const router = express.Router();

router.post(
  '/',
  [
    body('name', 'Name is required').notEmpty(),
    body('email', 'Please include a valid email').isEmail(),
    body('message', 'Message is required').notEmpty()
  ],
  submitContact
);

router.get('/', getContacts);

export default router;
